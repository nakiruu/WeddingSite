# Mulberry — Report Color Theme

A two-mode theme built from a single Color Hunt palette: a black → aubergine → mulberry → mauve purple ramp. **Mulberry Noir** is the dark mode; **Mulberry Bloom** is the light mode. Both keep the base frame — Cormorant Garamond display, Inter body, JetBrains Mono data, hairline rules, zero border-radius.

## Source palette

| Band | Hex | Character |
|---|---|---|
| P1 | `#17151A` | Near-black, faint purple |
| P2 | `#3D1E37` | Aubergine / wine |
| P3 | `#7B2E5E` | Mulberry magenta |
| P4 | `#AC6284` | Dusty mauve / rose |

All four bands are used in **both** modes — they're just remapped by luminance so the accent always has enough contrast against that mode's background. A single hue can't supply readable body text, visible hairlines, or a gain/loss signal, so `primary`, `secondary`, `neutral` and the `bull`/`bear` pair are **derived** to sit with the palette in each mode.

- **Dark** puts the palette to work as backgrounds and lifts the *lighter* mauve (P4) to the on-dark accent.
- **Light** flips it: the *darker* mulberry (P3) becomes the on-light accent, and the near-black (P1) becomes the ink.

---

## Dark — "Mulberry Noir"

| Token | Hex | Source | Role |
|---|---|---|---|
| `primary` | `#F2E7EC` | derived | Text — headings & body |
| `secondary` | `#C398AE` | derived | Muted labels, captions |
| `accent` | `#AC6284` | P4 | Eyebrow, rules, links, chart house-line |
| `accentDeep` | `#7B2E5E` | P3 | Rating badge & chip fills |
| `neutral` | `#4A3344` | derived | Hairlines, gridlines |
| `surface` | `#3D1E37` | P2 | Panels, callouts, table stripes |
| `page` | `#17151A` | P1 | Report background |
| `bull` | `#5FA98C` | derived | Gains, up figures, up chart line |
| `bear` | `#D96B6B` | derived | Losses, down figures, down chart line |

```js
// tailwind.config.js — Mulberry Noir · DARK
export default {
  theme: {
    extend: {
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        sans:    ['"Inter"', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        primary:    '#f2e7ec', // text (derived)
        secondary:  '#c398ae', // labels (derived)
        accent:     '#ac6284', // mauve · links, rules (P4)
        accentDeep: '#7b2e5e', // mulberry · chip fills (P3)
        neutral:    '#4a3344', // hairlines (derived)
        surface:    '#3d1e37', // aubergine panels (P2)
        page:       '#17151a', // background (P1)
        bull:       '#5fa98c', // gains (derived)
        bear:       '#d96b6b', // losses (derived)
      },
      borderRadius: { sm: '0px', md: '0px', lg: '0px' },
    },
  },
};
```

---

## Light — "Mulberry Bloom"

| Token | Hex | Source | Role |
|---|---|---|---|
| `primary` | `#17151A` | P1 | Text — headings & body |
| `secondary` | `#7D576B` | derived | Muted labels, captions |
| `accent` | `#7B2E5E` | P3 | Eyebrow, rules, links, chart house-line |
| `accentDeep` | `#3D1E37` | P2 | Rating badge & chip fills |
| `neutral` | `#DDD0D8` | derived | Hairlines, gridlines |
| `surface` | `#ECE0E7` | derived | Panels, callouts, table stripes |
| `page` | `#F5EDF1` | derived | Report background |
| `bull` | `#2F7D5F` | derived | Gains, up figures, up chart line |
| `bear` | `#B23B47` | derived | Losses, down figures, down chart line |

```js
// tailwind.config.js — Mulberry Bloom · LIGHT
export default {
  theme: {
    extend: {
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        sans:    ['"Inter"', 'sans-serif'],
        mono:    ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        primary:    '#17151a', // ink (P1)
        secondary:  '#7d576b', // muted mauve-gray (derived)
        accent:     '#7b2e5e', // mulberry · links, rules (P3)
        accentDeep: '#3d1e37', // aubergine · chip fills (P2)
        neutral:    '#ddd0d8', // hairlines (derived)
        surface:    '#ece0e7', // blush panels (derived)
        page:       '#f5edf1', // background (derived)
        bull:       '#2f7d5f', // gains (derived)
        bear:       '#b23b47', // losses (derived)
      },
      borderRadius: { sm: '0px', md: '0px', lg: '0px' },
    },
  },
};
```

> Optional soft-accent: the mauve `#AC6284` (P4) can serve as a secondary rule or the chart's consensus line in light mode, echoing dark mode's accent.

---

## Usage in the report (both modes)

- **Eyebrow / section markers** (`EQUITY RESEARCH`, `1. Executive Summary`): `accent`.
- **Body & metric values**: `primary`. **Metric labels & captions**: `secondary`.
- **Rating badge** (`HOLD`): `accentDeep` fill, `page` text. Swap to `bull` for Buy, `bear` for Sell so the badge carries the call.
- **Metric deltas** (`+57%`, `−$23.7B`): `bull` / `bear`.
- **Price-projection chart**: house/consensus line `accent`, target band a low-opacity `accentDeep` fill, up-scenario `bull`, down-scenario `bear`, current line `secondary` (dashed), gridlines `neutral`.
- **Tables**: header underline `accent`; gridlines `neutral`; alternating rows `surface`; first column `secondary`.
- **Panels / callouts** (RPO backlog, thesis box): `surface` fill, `neutral` border.

## Notes

- Nine tokens per mode: the base five (`primary`, `secondary`, `accent`, `neutral`, `surface`) plus `accentDeep`, `page`, and the `bull`/`bear` pair. `fontFamily` and `borderRadius` are unchanged from the base config.
- **Contrast:** in both modes, `primary` and `secondary` clear WCAG AA on `page` and `surface`. `accent` clears AA for large text, links and UI in both modes, and also clears AA for normal body text in light mode. `bull`/`bear` clear AA for figures against their mode's background.
- The two modes share token names, so a `dark:` variant in Tailwind can flip the whole report by swapping this one `colors` block.
